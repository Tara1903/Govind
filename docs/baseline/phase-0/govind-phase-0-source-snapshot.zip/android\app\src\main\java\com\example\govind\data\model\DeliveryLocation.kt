package com.example.govind.data.model

import kotlinx.serialization.Serializable

@Serializable
data class DeliveryLocation(
    val order_id: String,
    val estimated_distance_m: Int,
    val estimated_time_sec: Int,
    val updated_at: String,
    val delivery_partner_id: String? = null
)
