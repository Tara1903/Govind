package com.example.govind.data.repository

import com.example.govind.data.model.DeliveryLocation
import com.example.govind.data.remote.SupabaseApi
import com.example.govind.domain.repository.TrackingRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TrackingRepositoryImpl @Inject constructor(
    private val api: SupabaseApi
) : TrackingRepository {
    
    override fun listenToOrderTracking(orderId: String): Flow<DeliveryLocation?> = flow {
        // Fallback to polling simulating Supabase Realtime
        while(true) {
            try {
                val locations = api.getDeliveryLocation("eq.$orderId")
                emit(locations.firstOrNull())
            } catch (e: Exception) {
                // ignore or log
            }
            delay(3000)
        }
    }
}
