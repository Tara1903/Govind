"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { createClient } from "../../../utils/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";

export default function OrdersPage() {
  const supabase = createClient();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [deliveryPartners, setDeliveryPartners] = useState<any[]>([]);

  // Statuses list
  const statuses = ['PENDING', 'CONFIRMED', 'PREPARING', 'READY_FOR_DELIVERY', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED'];

  useEffect(() => {
    fetchOrders();
    fetchDeliveryPartners();
  }, []);

  async function fetchDeliveryPartners() {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('role', 'DELIVERY_PARTNER');
    if (data) setDeliveryPartners(data);
  }

  async function fetchOrders() {
    setLoading(true);
    const { data, error } = await supabase
      .from('orders')
      .select(`
        *,
        profiles!orders_user_id_fkey(name, phone)
      `)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setOrders(data);
    }
    setLoading(false);
  }

  const updateStatus = async (orderId: string, newStatus: string) => {
    await supabase.from('orders').update({ order_status: newStatus }).eq('id', orderId);
    fetchOrders();
  };

  const assignDeliveryPartner = async (orderId: string, partnerId: string) => {
    await supabase.from('orders').update({ delivery_partner_id: partnerId || null }).eq('id', orderId);
    fetchOrders();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Orders</h2>
        <Button onClick={fetchOrders}>Refresh</Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Loading orders...</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Delivery Partner</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-4">No orders found.</TableCell>
                    </TableRow>
                  )}
                  {orders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium text-xs font-mono">{order.id.split('-')[0]}...</TableCell>
                      <TableCell>{order.profiles?.name || 'Guest'} ({order.profiles?.phone || 'N/A'})</TableCell>
                      <TableCell>{new Date(order.created_at).toLocaleString()}</TableCell>
                      <TableCell>₹{order.total}</TableCell>
                      <TableCell>
                        <select 
                          className={`text-xs font-semibold rounded px-2 py-1 border ${
                            order.order_status === 'DELIVERED' ? 'bg-green-100 text-green-800' :
                            order.order_status === 'CANCELLED' ? 'bg-red-100 text-red-800' :
                            order.order_status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-blue-100 text-blue-800'
                          }`}
                          value={order.order_status}
                          onChange={(e) => updateStatus(order.id, e.target.value)}
                        >
                          {statuses.map(s => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </select>
                      </TableCell>
                      <TableCell>
                        {['PREPARING', 'READY_FOR_DELIVERY'].includes(order.order_status) ? (
                          <select
                            className="text-xs rounded px-2 py-1 border w-32"
                            value={order.delivery_partner_id || ''}
                            onChange={(e) => assignDeliveryPartner(order.id, e.target.value)}
                          >
                            <option value="">Unassigned</option>
                            {deliveryPartners.map(dp => (
                              <option key={dp.id} value={dp.id}>{dp.name || dp.phone}</option>
                            ))}
                          </select>
                        ) : (
                          <span className="text-xs text-gray-500">
                            {order.delivery_partner_id 
                              ? (deliveryPartners.find(dp => dp.id === order.delivery_partner_id)?.name || 'Assigned')
                              : 'N/A'
                            }
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={`/orders/${order.id}`}>View Details</Link>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
