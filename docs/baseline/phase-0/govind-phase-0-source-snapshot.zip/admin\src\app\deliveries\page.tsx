"use client";

import { useEffect, useState } from "react";
import { createClient } from "../../../utils/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";

export default function DeliveriesPage() {
  const supabase = createClient();
  const [deliveries, setDeliveries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDeliveries();

    // Subscribe to realtime location updates
    const channel = supabase
      .channel('schema-db-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'delivery_locations',
        },
        (payload) => {
          console.log('Location update:', payload);
          fetchDeliveries();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  async function fetchDeliveries() {
    setLoading(true);
    // Fetch active orders with OUT_FOR_DELIVERY status
    const { data: orders, error } = await supabase
      .from('orders')
      .select(`
        *,
        profiles!orders_delivery_partner_id_fkey(name, phone),
        customer:profiles!orders_user_id_fkey(name, phone)
      `)
      .eq('order_status', 'OUT_FOR_DELIVERY');

    if (!error && orders) {
      // For each order, fetch the latest location from delivery_locations
      const deliveriesData = await Promise.all(
        orders.map(async (order) => {
          if (!order.delivery_partner_id) return { ...order, location: null };
          
          const { data: locations } = await supabase
            .from('delivery_locations')
            .select('*')
            .eq('delivery_partner_id', order.delivery_partner_id)
            .order('created_at', { ascending: false })
            .limit(1);

          return {
            ...order,
            location: locations && locations.length > 0 ? locations[0] : null
          };
        })
      );
      setDeliveries(deliveriesData);
    }
    setLoading(false);
  }

  const getFreshness = (timestamp: string) => {
    if (!timestamp) return "N/A";
    const diffInSeconds = Math.floor((new Date().getTime() - new Date(timestamp).getTime()) / 1000);
    if (diffInSeconds < 60) return `${diffInSeconds} sec ago`;
    return `${Math.floor(diffInSeconds / 60)} min ago`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Live Deliveries</h2>
        <Button onClick={fetchDeliveries}>Refresh</Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Active Deliveries</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Loading deliveries...</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Partner</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Last Location</TableHead>
                    <TableHead>Freshness</TableHead>
                    <TableHead>ETA</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {deliveries.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-4">No active deliveries.</TableCell>
                    </TableRow>
                  )}
                  {deliveries.map((d) => (
                    <TableRow key={d.id}>
                      <TableCell className="font-medium text-xs font-mono">{d.id.split('-')[0]}...</TableCell>
                      <TableCell>{d.profiles?.name || 'Unknown'} ({d.profiles?.phone || 'N/A'})</TableCell>
                      <TableCell>{d.customer?.name || 'Guest'} ({d.customer?.phone || 'N/A'})</TableCell>
                      <TableCell>
                        {d.location ? `${d.location.latitude?.toFixed(4)}, ${d.location.longitude?.toFixed(4)}` : 'Waiting...'}
                      </TableCell>
                      <TableCell>
                        {d.location ? getFreshness(d.location.created_at) : 'N/A'}
                      </TableCell>
                      <TableCell>
                        {/* Placeholder for ETA/Distance - logic goes here once real distance calc is available */}
                        {d.location ? '15 mins' : 'N/A'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
