package com.example.govind.ui.features.wholesale

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.govind.data.model.Product
import com.example.govind.domain.repository.GovindRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class WholesaleUiState(
    val isLoading: Boolean = true,
    val items: List<Product> = emptyList(),
    val error: String? = null
)

@HiltViewModel
class WholesaleViewModel @Inject constructor(
    private val repository: GovindRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(WholesaleUiState())
    val uiState: StateFlow<WholesaleUiState> = _uiState.asStateFlow()

    init {
        loadWholesaleItems()
    }

    private fun loadWholesaleItems() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            try {
                repository.getWholesaleItems().collect { products ->
                    if (products.isEmpty()) {
                        val fallbackItems = listOf(
                            Product(
                                id = "ws_tomato_1",
                                name = "Tomato (Wholesale)",
                                slug = "ws-tomato-1",
                                price = 1000.0,
                                sellingPrice = 900.0,
                                unit = "20kg",
                                stockQuantity = 50,
                                categoryId = "wholesale"
                            ),
                            Product(
                                id = "ws_onion_1",
                                name = "Onion (Wholesale)",
                                slug = "ws-onion-1",
                                price = 1250.0,
                                sellingPrice = 1100.0,
                                unit = "25kg",
                                stockQuantity = 50,
                                categoryId = "wholesale"
                            )
                        )
                        _uiState.value = _uiState.value.copy(items = fallbackItems, isLoading = false)
                    } else {
                        _uiState.value = _uiState.value.copy(items = products, isLoading = false)
                    }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Failed to load wholesale items"
                )
            }
        }
    }

    fun addToCart(product: Product) {
        viewModelScope.launch {
            repository.addToCart(product, 1, "WHOLESALE")
        }
    }
}
