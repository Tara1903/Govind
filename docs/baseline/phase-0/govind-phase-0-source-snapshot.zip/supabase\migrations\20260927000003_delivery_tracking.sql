-- Migration 20260927000003_delivery_tracking.sql

-- Add role to profiles if not exists
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'CUSTOMER' CHECK (role IN ('CUSTOMER', 'ADMIN', 'DELIVERY_PARTNER'));

-- Add delivery info to orders
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_partner_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS dest_latitude DECIMAL(10, 8);
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS dest_longitude DECIMAL(10, 8);

-- Add lat/lng to addresses
ALTER TABLE public.addresses ADD COLUMN IF NOT EXISTS latitude DECIMAL(10, 8);
ALTER TABLE public.addresses ADD COLUMN IF NOT EXISTS longitude DECIMAL(10, 8);

-- Create delivery_locations table for live tracking
CREATE TABLE public.delivery_locations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE UNIQUE,
    delivery_partner_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(10, 8) NOT NULL,
    accuracy DECIMAL(10, 2),
    speed DECIMAL(10, 2),
    heading DECIMAL(10, 2),
    estimated_distance_m INTEGER,
    estimated_time_sec INTEGER,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.delivery_locations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Delivery partner can manage their own location" ON public.delivery_locations FOR ALL USING (auth.uid() = delivery_partner_id);
CREATE POLICY "Customers can view their order tracking" ON public.delivery_locations FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.orders WHERE id = delivery_locations.order_id AND customer_id = auth.uid())
);
CREATE POLICY "Admins can view all tracking" ON public.delivery_locations FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'ADMIN')
);

-- Enable Realtime for delivery_locations
alter publication supabase_realtime add table public.delivery_locations;

-- Create an RPC to calculate ETA and distance on location update
CREATE OR REPLACE FUNCTION update_delivery_location(
    p_order_id UUID,
    p_lat DECIMAL,
    p_lng DECIMAL,
    p_accuracy DECIMAL,
    p_speed DECIMAL,
    p_heading DECIMAL
) RETURNS void AS $$
DECLARE
    v_partner_id UUID;
    v_dest_lat DECIMAL;
    v_dest_lng DECIMAL;
    v_distance_m INTEGER;
    v_eta_sec INTEGER;
    v_speed_ms DECIMAL;
BEGIN
    SELECT delivery_partner_id, dest_latitude, dest_longitude 
    INTO v_partner_id, v_dest_lat, v_dest_lng 
    FROM public.orders WHERE id = p_order_id;
    
    -- Haversine distance calculation
    IF v_dest_lat IS NOT NULL AND v_dest_lng IS NOT NULL THEN
        v_distance_m := ( 6371000 * acos( cos( radians(v_dest_lat) ) * cos( radians( p_lat ) ) * cos( radians( p_lng ) - radians(v_dest_lng) ) + sin( radians(v_dest_lat) ) * sin( radians( p_lat ) ) ) );
        -- Assume 25 km/h average speed in city if speed is 0 or low (approx 7 m/s)
        v_speed_ms := GREATEST(p_speed, 7.0); 
        v_eta_sec := v_distance_m / v_speed_ms;
    END IF;

    INSERT INTO public.delivery_locations (
        order_id, delivery_partner_id, latitude, longitude, accuracy, speed, heading, estimated_distance_m, estimated_time_sec, updated_at
    ) VALUES (
        p_order_id, v_partner_id, p_lat, p_lng, p_accuracy, p_speed, p_heading, v_distance_m, v_eta_sec, NOW()
    ) ON CONFLICT (order_id) DO UPDATE SET
        latitude = EXCLUDED.latitude,
        longitude = EXCLUDED.longitude,
        accuracy = EXCLUDED.accuracy,
        speed = EXCLUDED.speed,
        heading = EXCLUDED.heading,
        estimated_distance_m = EXCLUDED.estimated_distance_m,
        estimated_time_sec = EXCLUDED.estimated_time_sec,
        updated_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
