package com.example.govind.ui.shared

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.govind.theme.GovindTheme
import com.example.govind.ui.navigation.AppState
import com.example.govind.ui.navigation.GovindExperience

@Composable
fun PillExperienceSwitcher() {
    val currentExperience by AppState.currentExperience.collectAsState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ExperiencePill(
            title = "Fresh",
            icon = "🥬",
            isSelected = currentExperience == GovindExperience.FRESH,
            onClick = { AppState.switchExperience(GovindExperience.FRESH) },
            modifier = Modifier.weight(1f)
        )
        ExperiencePill(
            title = "Kitchen",
            icon = "🍛",
            isSelected = currentExperience == GovindExperience.KITCHEN,
            onClick = { AppState.switchExperience(GovindExperience.KITCHEN) },
            modifier = Modifier.weight(1f)
        )
        ExperiencePill(
            title = "Wholesale",
            icon = "📦",
            isSelected = currentExperience == GovindExperience.WHOLESALE,
            onClick = { AppState.switchExperience(GovindExperience.WHOLESALE) },
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun ExperiencePill(
    title: String,
    icon: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = if (isSelected) GovindTheme.colors.govindGreen else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    val contentColor = if (isSelected) GovindTheme.colors.pureWhite else GovindTheme.colors.textSecondary

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(24.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(text = icon, fontSize = 14.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                color = contentColor,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}
