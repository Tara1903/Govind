import { createClient } from "../../../../utils/supabase/server";
import OrderDetailsClient from "./OrderDetailsClient";

export default async function OrderDetailsPage({ params }: { params: { id: string } }) {
  const supabase = await createClient();
  const { id } = params;

  const { data: order, error: orderError } = await supabase
    .from("orders")
    .select(`
      *,
      profiles!orders_user_id_fkey(name, phone, address)
    `)
    .eq("id", id)
    .single();

  const { data: items, error: itemsError } = await supabase
    .from("order_items")
    .select(`
      *,
      products(name, category, unit)
    `)
    .eq("order_id", id);

  if (orderError || !order) {
    return <div>Order not found.</div>;
  }

  return (
    <div className="space-y-6">
      <OrderDetailsClient order={order} items={items || []} />
    </div>
  );
}
