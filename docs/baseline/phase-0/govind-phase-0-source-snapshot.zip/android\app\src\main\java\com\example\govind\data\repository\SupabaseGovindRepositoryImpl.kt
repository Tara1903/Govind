package com.example.govind.data.repository

import com.example.govind.data.local.CartDao
import com.example.govind.data.local.CartEntity
import com.example.govind.data.local.SessionManager
import com.example.govind.data.model.*
import com.example.govind.data.remote.SupabaseApi
import com.example.govind.data.remote.PaymentGatewayApi
import com.example.govind.domain.repository.GovindRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.flow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SupabaseGovindRepositoryImpl @Inject constructor(
    private val paymentGatewayApi: com.example.govind.data.remote.PaymentGatewayApi,
    private val api: SupabaseApi,
    private val cartDao: CartDao,
    private val sessionManager: SessionManager
) : GovindRepository {
    
    // Auth
    override suspend fun verifyOtp(email: String, token: String): Result<Unit> {
        return try {
            val response = api.verifyOtp(com.example.govind.data.model.VerifyOtpRequest(type = "email", email = email, token = token))
            sessionManager.accessToken = response.accessToken
            sessionManager.refreshToken = response.refreshToken
            sessionManager.userId = response.user.id
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    override suspend fun sendOtp(email: String): Result<Unit> {
        return try {
            api.sendOtp(com.example.govind.data.model.SendOtpRequest(email = email, createUser = true))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    override suspend fun logout() {
        sessionManager.clearSession()
        cartDao.clearCart()
    }
    
    override fun isUserLoggedIn(): Boolean = sessionManager.isLoggedIn
    override fun getUserId(): String? = sessionManager.userId
    override fun isLoggedIn(): Boolean = sessionManager.isLoggedIn

        override suspend fun getUserProfile(): Result<com.example.govind.data.model.Profile?> {
        return try {
            val userId = sessionManager.userId ?: throw Exception("User not logged in")
            val profiles = api.getProfile("eq.$userId")
            Result.success(profiles.firstOrNull())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateUserPhone(phone: String): Result<Unit> {
        return try {
            val userId = sessionManager.userId ?: throw Exception("User not logged in")
            val updates = kotlinx.serialization.json.buildJsonObject {
                put("phone", kotlinx.serialization.json.JsonPrimitive(phone))
            }
            api.updateProfile("eq.$userId", updates)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Products
    override fun getFreshBoardProducts(): Flow<List<Product>> = flow {
        emit(api.getFreshBoardProducts())
    }

    override fun getCategories(): Flow<List<Category>> = flow { emit(api.getCategories()) }
    override fun getFeaturedProducts(): Flow<List<Product>> = flow { emit(api.getFeaturedProducts()) }
    override fun getPacks(): Flow<List<Product>> = flow { emit(api.getProductsByType("eq.PACK")) }
    override fun getCombos(): Flow<List<Product>> = flow { emit(api.getProductsByType("eq.COMBO")) }
    override fun getProductsByCategory(categoryId: String): Flow<List<Product>> = flow { emit(api.getProductsByCategory("eq.$categoryId")) }
    override fun getProductDetails(productId: String): Flow<Product?> = flow { emit(api.getProductDetails("eq.$productId").firstOrNull()) }
    override fun searchProducts(query: String): Flow<List<Product>> = flow { emit(api.searchProducts("ilike.%$query%")) }

    // Cart
    override fun getGlobalCart(): Flow<Cart?> = cartDao.getCartItems().map { entities ->
        Cart(
            id = "global_cart",
            profileId = sessionManager.userId ?: "guest",
            items = entities.map { it.toCartItem() }
        )
    }

    override suspend fun addToCart(product: Product, quantity: Int, experienceType: String) {
        val existingItem = cartDao.getCartItemForExperience(product.id, experienceType)
        if (existingItem != null) {
            cartDao.updateQuantity(product.id, experienceType, existingItem.quantity + quantity)
        } else {
            val entity = CartEntity(
                id = product.id,
                productId = product.id,
                name = product.name,
                slug = product.slug,
                price = product.price,
                sellingPrice = product.sellingPrice,
                description = product.description,
                imageUrl = product.imageUrl,
                categoryId = product.categoryId,
                unit = product.unit,
                quantity = quantity,
                experienceType = experienceType
            )
            cartDao.insertItem(entity)
        }
    }

    override suspend fun removeFromCart(cartItemId: String, experienceType: String) {
        cartDao.deleteItem(cartItemId, experienceType)
    }

    override suspend fun updateCartItemQuantity(cartItemId: String, experienceType: String, quantity: Int) {
        if (quantity <= 0) {
            cartDao.deleteItem(cartItemId, experienceType)
        } else {
            cartDao.updateQuantity(cartItemId, experienceType, quantity)
        }
    }

    // Addresses
        override fun getAddresses(): Flow<List<com.example.govind.data.model.Address>> = flow {
        val uid = sessionManager.userId
        if (uid != null) {
            try {
                emit(api.getAddresses("eq.$uid"))
            } catch (e: Exception) {
                emit(emptyList())
            }
        } else {
            emit(emptyList())
        }
    }

    override suspend fun addAddress(name: String, phone: String, house: String, street: String, area: String, city: String, pincode: String): Result<Unit> {
        return try {
            val uid = sessionManager.userId ?: throw Exception("Not logged in")
            val addressJson = kotlinx.serialization.json.buildJsonObject {
                put("profile_id", kotlinx.serialization.json.JsonPrimitive(uid))
                put("name", kotlinx.serialization.json.JsonPrimitive(name))
                put("phone", kotlinx.serialization.json.JsonPrimitive(phone))
                put("house", kotlinx.serialization.json.JsonPrimitive(house))
                put("street", kotlinx.serialization.json.JsonPrimitive(street))
                put("area", kotlinx.serialization.json.JsonPrimitive(area))
                put("city", kotlinx.serialization.json.JsonPrimitive(city))
                put("pincode", kotlinx.serialization.json.JsonPrimitive(pincode))
            }
            api.addAddress(addressJson)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Order
        override suspend fun placeGlobalOrder(addressId: String, paymentMethod: String): Result<com.example.govind.data.model.Order> {
        val cartEntities = cartDao.getCartItems().first()
        val cartItems = cartEntities.map { it.toCartItem() }
        if (cartItems.isEmpty()) return Result.failure(Exception("Cart is empty"))
        
        val subtotal = cartItems.sumOf { it.product.sellingPrice * it.quantity }
        val deliveryCharge = if (subtotal > 200) 0.0 else 30.0
        val total = subtotal + deliveryCharge
        
        val itemsJson = kotlinx.serialization.json.buildJsonArray {
            cartItems.forEach { item ->
                add(kotlinx.serialization.json.buildJsonObject {
                    put("product_id", kotlinx.serialization.json.JsonPrimitive(item.product.id))
                    put("product_name", kotlinx.serialization.json.JsonPrimitive(item.product.name))
                    put("unit", kotlinx.serialization.json.JsonPrimitive(item.product.unit))
                    put("price", kotlinx.serialization.json.JsonPrimitive(item.product.sellingPrice))
                    put("quantity", kotlinx.serialization.json.JsonPrimitive(item.quantity))
                    put("experience_type", kotlinx.serialization.json.JsonPrimitive(item.experienceType))
                    put("discount", kotlinx.serialization.json.JsonPrimitive(
                        if (item.product.price > item.product.sellingPrice) 
                            item.product.price - item.product.sellingPrice 
                        else 0.0
                    ))
                })
            }
        }
        
        val request = kotlinx.serialization.json.buildJsonObject {
            put("p_customer_id", kotlinx.serialization.json.JsonPrimitive(sessionManager.userId))
            put("p_subtotal", kotlinx.serialization.json.JsonPrimitive(subtotal))
            put("p_discount", kotlinx.serialization.json.JsonPrimitive(0.0))
            put("p_coupon_id", kotlinx.serialization.json.JsonPrimitive(null as String?))
            put("p_tax", kotlinx.serialization.json.JsonPrimitive(0.0))
            put("p_delivery_charge", kotlinx.serialization.json.JsonPrimitive(deliveryCharge))
            put("p_total", kotlinx.serialization.json.JsonPrimitive(total))
            put("p_address_id", kotlinx.serialization.json.JsonPrimitive(addressId))
            put("p_payment_method", kotlinx.serialization.json.JsonPrimitive(paymentMethod))
            put("p_items", itemsJson)
        }
        
        return try {
            val orderId = api.createOrderRpc(request).replace("\"", "")
            
            var checkoutUrlValue: String? = null
            if (paymentMethod == "ONLINE") {
                val pRequest = com.example.govind.data.remote.PaymentGatewayRequest(amount = total, returnUrl = "govind://payment-success/$orderId")
                val pResponse = paymentGatewayApi.createOrder("test_api_key_123", pRequest)
                if (pResponse.success) {
                    checkoutUrlValue = pResponse.data?.checkoutUrl?.replace("localhost", "10.0.2.2")
                } else {
                    return Result.failure(Exception("Payment Gateway Error"))
                }
            }
            cartDao.clearCart()
            Result.success(com.example.govind.data.model.Order(
                id = orderId,
                  customerId = sessionManager.userId ?: "guest",
                  subtotal = subtotal,
                  total = total,
                  paymentMethod = paymentMethod,
                  paymentStatus = "PENDING",
                  orderStatus = if (paymentMethod == "ONLINE") "INITIATED" else "CONFIRMED",
                  checkoutUrl = checkoutUrlValue
            ))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    
    override fun getOrders(): Flow<List<Order>> = flow {
        val uid = sessionManager.userId
        if (uid != null) {
            while(true) {
                try {
                    emit(api.getOrders("eq.$uid"))
                } catch (e: Exception) {}
                kotlinx.coroutines.delay(3000)
            }
        } else {
            emit(emptyList())
        }
    }

    override fun getKitchenMenuItems(): Flow<List<Product>> = flow {
        try { emit(api.getKitchenMenuItems()) } catch (e: Exception) { emit(emptyList()) }
    }

    override fun getWholesaleItems(): Flow<List<Product>> = flow {
        try { emit(api.getWholesaleItems()) } catch (e: Exception) { emit(emptyList()) }
    }

    override suspend fun getDeliveryPartnerOrders(): Result<List<com.example.govind.data.model.Order>> {
        val uid = sessionManager.userId ?: return Result.failure(Exception("Not logged in"))
        return try {
            val orders = api.getDeliveryPartnerOrders("eq.$uid")
            Result.success(orders)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateOrderStatus(orderId: String, status: String): Result<Unit> {
        return try {
            val request = kotlinx.serialization.json.buildJsonObject {
                put("order_status", kotlinx.serialization.json.JsonPrimitive(status))
            }
            api.updateOrderStatus("eq.$orderId", request)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateDeliveryLocation(orderId: String, lat: Double, lng: Double, accuracy: Float, speed: Float, heading: Float): Result<Unit> {
        return try {
            val request = kotlinx.serialization.json.buildJsonObject {
                put("p_order_id", kotlinx.serialization.json.JsonPrimitive(orderId))
                put("p_lat", kotlinx.serialization.json.JsonPrimitive(lat))
                put("p_lng", kotlinx.serialization.json.JsonPrimitive(lng))
                put("p_accuracy", kotlinx.serialization.json.JsonPrimitive(accuracy.toDouble()))
                put("p_speed", kotlinx.serialization.json.JsonPrimitive(speed.toDouble()))
                put("p_heading", kotlinx.serialization.json.JsonPrimitive(heading.toDouble()))
            }
            api.updateDeliveryLocation(request)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}








































