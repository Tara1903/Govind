package com.example.govind.ui.features.kitchen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.govind.data.model.Product
import coil3.compose.AsyncImage
import com.example.govind.theme.GovindTheme
import com.example.govind.ui.shared.PillExperienceSwitcher

// Fallback hardcoded data when backend returns no results
data class MenuItem(
    val id: String,
    val name: String,
    val description: String,
    val price: Int,
    val category: String,
    val emoji: String = "🍲"
)

val kitchenMenuData = listOf(
    MenuItem("1", "Rajma Chawal", "Comforting kidney beans curry with rice", 89, "Meals", "🍛"),
    MenuItem("2", "Dal Makhani", "Creamy and buttery black lentils", 79, "Meals", "🍲"),
    MenuItem("3", "Chole Bhature", "Spicy chickpea curry with fried bread", 99, "Meals", "🫓"),
    MenuItem("4", "Aloo Paratha", "Potato stuffed flatbread with butter", 49, "Paratha", "🥙"),
    MenuItem("5", "Paneer Paratha", "Cottage cheese stuffed flatbread", 69, "Paratha", "🥙"),
    MenuItem("6", "Special Thali", "Complete meal with dal, paneer, rice, roti, and sweet", 149, "Thali", "🍱"),
    MenuItem("7", "Raita", "Cooling yogurt with cucumber and spices", 29, "Sides", "🥣"),
    MenuItem("8", "Butter Naan", "Soft flatbread cooked in tandoor with butter", 20, "Sides", "🫓")
)

val kitchenAccentColor = Color(0xFFF5450D)

// ─── Shared Top Bar ────────────────────────────────────────────────────────────
@Composable
fun KitchenTopBar() {
    Surface(
        color = MaterialTheme.colorScheme.background,
        shadowElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(
                        id = com.example.govind.R.drawable.ic_launcher_squircle
                    ),
                    contentDescription = "Govind Logo",
                    modifier = Modifier.size(40.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "GOVIND",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = GovindTheme.colors.govindGreen
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            PillExperienceSwitcher()
        }
    }
}

// ─── Home Screen ───────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KitchenHomeScreen(
    onNavigateToCart: () -> Unit,

    viewModel: KitchenViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    // Live chip categories derived from backend, fallback to static
    val chips = listOf("All", "Meals", "Paratha", "Thali", "Sides")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GovindTheme.colors.softCream)
    ) {
        KitchenTopBar()

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // ── Hero ──────────────────────────────────────────
            Text("Order fast", style = MaterialTheme.typography.labelMedium, color = GovindTheme.colors.textSecondary)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Food first, browsing first, checkout in a few taps.",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = GovindTheme.colors.textPrimary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                KitchenMetaChip(icon = Icons.Default.LocationOn, text = "Indore")
                KitchenMetaChip(icon = Icons.Default.Star, text = "4.8 • 10K+ Orders")
            }
            Spacer(modifier = Modifier.height(24.dp))

            // ── Cart summary promo card ──────────────────────
            val cartCount = uiState.cart?.items?.sumOf { it.quantity } ?: 0
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GovindTheme.colors.warmWhite),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Cart", style = MaterialTheme.typography.labelMedium, color = GovindTheme.colors.textSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        if (cartCount > 0) "$cartCount item${if (cartCount > 1) "s" else ""} in your kitchen cart"
                        else "Start with quick picks",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Jump into best sellers, daily plans, and category shortcuts.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = GovindTheme.colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onNavigateToCart,
                        colors = ButtonDefaults.buttonColors(containerColor = kitchenAccentColor),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (cartCount > 0) "View cart" else "Browse menu")
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ── Quick Filters ─────────────────────────────────
            Text("Quick filters", style = MaterialTheme.typography.labelMedium, color = GovindTheme.colors.textSecondary)
            Text("Find the right food mood", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(chips) { chip ->
                    val isSelected = chip == uiState.activeCategory
                    Surface(
                        color = if (isSelected) kitchenAccentColor else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.clickable { viewModel.setActiveCategory(chip) }
                    ) {
                        Text(
                            chip,
                            color = if (isSelected) Color.White else GovindTheme.colors.textPrimary,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))

            // ── Menu Items ────────────────────────────────────
            Text("Quick order", style = MaterialTheme.typography.labelMedium, color = GovindTheme.colors.textSecondary)
            Text("Top food items", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            when {
                uiState.isLoading -> {
                    repeat(3) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
                uiState.error != null -> {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Couldn't load menu", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = { viewModel.retry() }, colors = ButtonDefaults.buttonColors(containerColor = kitchenAccentColor)) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Retry")
                        }
                    }
                }
                uiState.filteredItems.isNotEmpty() -> {
                    // Real data from Supabase
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        uiState.filteredItems.take(6).forEach { product ->
                            ProductMenuCard(product = product, onAddToCart = { viewModel.addToCart(product) })
                        }
                    }
                }
                else -> {
                    // Fallback hardcoded data (no KITCHEN items in DB yet)
                    val fallbackItems = if (uiState.activeCategory == "All") kitchenMenuData
                    else kitchenMenuData.filter { it.category == uiState.activeCategory }
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        fallbackItems.forEach { item -> 
                            FallbackMenuCard(
                                item = item,
                                onAddToCart = {
                                    viewModel.addToCart(
                                        Product(
                                            id = "fallback_${item.id}",
                                            name = item.name,
                                            slug = "fallback_${item.id}",
                                            description = item.description,
                                            price = item.price.toDouble(),
                                            sellingPrice = item.price.toDouble(),
                                            unit = "plate",
                                            categoryId = "kitchen",
                                            stockQuantity = 100
                                        )
                                    )
                                }
                            ) 
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // ── Category block ────────────────────────────────
            Text("Categories", style = MaterialTheme.typography.labelMedium, color = GovindTheme.colors.textSecondary)
            Text("Tap into the menu section", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            val categoryItems = listOf("Meals" to "🍛", "Paratha" to "🥙", "Thali" to "🍱", "Sides" to "🥣")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(categoryItems) { (name, emoji) ->
                    Card(
                        modifier = Modifier.size(100.dp).clickable { viewModel.setActiveCategory(name) },
                        colors = CardDefaults.cardColors(containerColor = GovindTheme.colors.warmWhite),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(emoji, fontSize = 32.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // ── Plans ─────────────────────────────────────────
            Text("Plans & combos", style = MaterialTheme.typography.labelMedium, color = GovindTheme.colors.textSecondary)
            Text("Shortcuts for repeat ordering", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF0ED)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Subscription", style = MaterialTheme.typography.labelMedium, color = kitchenAccentColor)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Monthly Thali Plan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Get daily fresh meals delivered automatically. Cancel anytime.", style = MaterialTheme.typography.bodyMedium, color = GovindTheme.colors.textSecondary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = { /* Disabled for now */ }, colors = ButtonDefaults.buttonColors(containerColor = kitchenAccentColor), shape = RoundedCornerShape(12.dp)) {
                        Text("Explore plans")
                    }
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

// ─── Menu Screen (full browse) ─────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KitchenMenuScreen(
    viewModel: KitchenViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()
    val chips = listOf("All", "Meals", "Paratha", "Thali", "Sides")
    val priceFilters = listOf("All", "Under ₹100", "₹100 - ₹300", "Above ₹300")

    Column(modifier = Modifier.fillMaxSize().background(GovindTheme.colors.softCream)) {
        KitchenTopBar()

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            Text("Browse menu", style = MaterialTheme.typography.labelMedium, color = GovindTheme.colors.textSecondary)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Search first, filter fast, and add food without leaving the flow.",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = GovindTheme.colors.textPrimary
            )
            Spacer(modifier = Modifier.height(24.dp))

            // Toolbar card
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = GovindTheme.colors.warmWhite), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Categories", style = MaterialTheme.typography.labelMedium, color = GovindTheme.colors.textSecondary)
                    Text("Jump faster", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(chips) { chip ->
                            val isSelected = chip == uiState.activeCategory
                            Surface(
                                color = if (isSelected) kitchenAccentColor else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.clickable { viewModel.setActiveCategory(chip) }
                            ) {
                                Text(chip, color = if (isSelected) Color.White else GovindTheme.colors.textPrimary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Text("Spend range", style = MaterialTheme.typography.labelMedium, color = GovindTheme.colors.textSecondary)
                    Text("Keep pricing visible", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(priceFilters) { filter ->
                            val isSelected = filter == uiState.activePriceFilter
                            Surface(
                                color = if (isSelected) kitchenAccentColor else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.clickable { viewModel.setActivePriceFilter(filter) }
                            ) {
                                Text(filter, color = if (isSelected) Color.White else GovindTheme.colors.textPrimary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            Text("Menu results", style = MaterialTheme.typography.labelMedium, color = GovindTheme.colors.textSecondary)
            Text("Tap to add", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            when {
                uiState.isLoading -> {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = kitchenAccentColor)
                    }
                }
                uiState.filteredItems.isNotEmpty() -> {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        uiState.filteredItems.forEach { product ->
                            ProductMenuCard(product = product, onAddToCart = { viewModel.addToCart(product) })
                        }
                    }
                }
                else -> {
                    val fallbackItems = if (uiState.activeCategory == "All") kitchenMenuData
                    else kitchenMenuData.filter { it.category == uiState.activeCategory }
                    if (fallbackItems.isEmpty()) {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("No dishes match these filters", color = GovindTheme.colors.textSecondary)
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            fallbackItems.forEach { item -> 
                                FallbackMenuCard(
                                    item = item,
                                    onAddToCart = {
                                        viewModel.addToCart(
                                            Product(
                                                id = "fallback_${item.id}",
                                                name = item.name,
                                                slug = "fallback_${item.id}",
                                                description = item.description,
                                                price = item.price.toDouble(),
                                                sellingPrice = item.price.toDouble(),
                                                unit = "plate",
                                                categoryId = "kitchen",
                                                stockQuantity = 100
                                            )
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

// ─── Card components ───────────────────────────────────────────────────────────

@Composable
fun ProductMenuCard(product: Product, onAddToCart: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = GovindTheme.colors.pureWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(80.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (product.imageUrl != null) {
                    AsyncImage(
                        model = product.imageUrl,
                        contentDescription = product.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                    )
                } else {
                    Text("🍛", fontSize = 40.sp)
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (!product.description.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(product.description, style = MaterialTheme.typography.bodySmall, color = GovindTheme.colors.textSecondary, maxLines = 2)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("₹${product.sellingPrice.toInt()}", style = MaterialTheme.typography.titleMedium, color = kitchenAccentColor, fontWeight = FontWeight.Bold)
                    if (product.price > product.sellingPrice) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("₹${product.price.toInt()}", style = MaterialTheme.typography.bodySmall, color = GovindTheme.colors.textSecondary)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("/ ${product.unit}", style = MaterialTheme.typography.bodySmall, color = GovindTheme.colors.textSecondary)
                }
            }
            Button(
                onClick = onAddToCart,
                colors = ButtonDefaults.buttonColors(containerColor = GovindTheme.colors.softGreen, contentColor = GovindTheme.colors.govindGreen),
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(width = 64.dp, height = 36.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("ADD", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun FallbackMenuCard(item: MenuItem, onAddToCart: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = GovindTheme.colors.pureWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(80.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                Text(item.emoji, fontSize = 40.sp)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(item.description, style = MaterialTheme.typography.bodySmall, color = GovindTheme.colors.textSecondary, maxLines = 2)
                Spacer(modifier = Modifier.height(8.dp))
                Text("₹${item.price}", style = MaterialTheme.typography.titleMedium, color = kitchenAccentColor, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onAddToCart,
                colors = ButtonDefaults.buttonColors(containerColor = GovindTheme.colors.softGreen, contentColor = GovindTheme.colors.govindGreen),
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(width = 64.dp, height = 36.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("ADD", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun KitchenMetaChip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), shape = RoundedCornerShape(12.dp)) {
        Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(14.dp), tint = GovindTheme.colors.textSecondary)
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = text, style = MaterialTheme.typography.labelSmall, color = GovindTheme.colors.textSecondary)
        }
    }
}




