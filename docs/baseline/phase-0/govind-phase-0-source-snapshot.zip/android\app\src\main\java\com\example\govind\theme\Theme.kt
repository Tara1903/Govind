package com.example.govind.theme

import androidx.compose.runtime.CompositionLocalProvider
import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = FreshGreen,
    onPrimary = PureWhite,
    primaryContainer = PrimaryDarkGreen,
    onPrimaryContainer = PureWhite,
    secondary = Orange,
    onSecondary = PureWhite,
    background = Color(0xFF121212),
    onBackground = PureWhite,
    surface = Color(0xFF1E1E1E),
    onSurface = PureWhite,
    surfaceVariant = Color(0xFF2D2D2D),
    onSurfaceVariant = Color(0xFFB3B3B3),
    error = Orange
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryDarkGreen,
    onPrimary = PureWhite,
    primaryContainer = SoftGreenTint,
    onPrimaryContainer = PrimaryDarkGreen,
    secondary = FreshGreen,
    onSecondary = PureWhite,
    secondaryContainer = FreshGreenTint,
    onSecondaryContainer = PrimaryDarkGreen,
    tertiary = Orange,
    onTertiary = PureWhite,
    tertiaryContainer = SoftOrangeTint,
    onTertiaryContainer = Orange,
    background = WarmWhite,
    onBackground = PrimaryText,
    surface = PureWhite,
    onSurface = PrimaryText,
    surfaceVariant = WarmWhite,
    onSurfaceVariant = SecondaryText,
    outline = NeutralBorder,
    error = Orange
)


@Composable
fun GovindTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    CompositionLocalProvider(
        LocalGovindColors provides defaultGovindColors
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = Shapes,
            content = content
        )
    }
}
