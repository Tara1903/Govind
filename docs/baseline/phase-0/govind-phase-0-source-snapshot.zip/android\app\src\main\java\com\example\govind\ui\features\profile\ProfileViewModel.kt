package com.example.govind.ui.features.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.govind.data.local.SessionManager
import com.example.govind.domain.repository.GovindRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProfileUiState(
    val name: String = "",
    val phone: String = "",
    val initial: String = "U",
    val isLoading: Boolean = false,
    val isLoggedOut: Boolean = false
)

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val sessionManager: SessionManager,
    private val repository: GovindRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState(isLoading = true))
    val uiState = _uiState.asStateFlow()

    init {
        loadProfile()
    }

    private fun loadProfile() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val result = repository.getUserProfile()
            if (result.isSuccess) {
                val profile = result.getOrNull()
                val name = profile?.name ?: "User"
                val phone = profile?.phone ?: ""
                val initial = if (name.isNotEmpty()) name.substring(0, 1).uppercase() else "U"
                _uiState.value = ProfileUiState(name = name, phone = phone, initial = initial, isLoading = false)
            } else {
                val name = sessionManager.userId?.take(5) ?: "Guest"
                _uiState.value = ProfileUiState(name = name, phone = "", initial = "G", isLoading = false)
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.logout()
            _uiState.value = _uiState.value.copy(isLoading = false, isLoggedOut = true)
        }
    }
}



