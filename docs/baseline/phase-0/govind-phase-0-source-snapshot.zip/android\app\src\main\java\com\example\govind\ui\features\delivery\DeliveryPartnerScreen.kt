package com.example.govind.ui.features.delivery

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.govind.DeliveryTrackingService
import com.example.govind.data.model.Order

@Composable
fun DeliveryPartnerScreen(
    viewModel: DeliveryPartnerViewModel = hiltViewModel()
) {
    val orders by viewModel.orders.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "My Deliveries", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
        } else if (orders.isEmpty()) {
            Text("No deliveries assigned.", modifier = Modifier.align(Alignment.CenterHorizontally))
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(orders) { order ->
                    DeliveryOrderCard(
                        order = order,
                        onStartDelivery = {
                            val intent = Intent(context, DeliveryTrackingService::class.java).apply {
                                action = DeliveryTrackingService.ACTION_START
                                putExtra(DeliveryTrackingService.EXTRA_ORDER_ID, order.id)
                            }
                            context.startForegroundService(intent)
                        },
                        onMarkDelivered = {
                            viewModel.markDelivered(order.id) {
                                val intent = Intent(context, DeliveryTrackingService::class.java).apply {
                                    action = DeliveryTrackingService.ACTION_STOP
                                }
                                context.startService(intent)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DeliveryOrderCard(
    order: Order,
    onStartDelivery: () -> Unit,
    onMarkDelivered: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Order ID: ${order.id}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Status: ${order.orderStatus}", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onStartDelivery) {
                    Text("Start Delivery")
                }
                Button(onClick = onMarkDelivered) {
                    Text("Mark Delivered")
                }
            }
        }
    }
}
