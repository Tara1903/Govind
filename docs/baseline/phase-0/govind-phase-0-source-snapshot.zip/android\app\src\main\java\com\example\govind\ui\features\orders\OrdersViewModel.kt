package com.example.govind.ui.features.orders

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.govind.data.model.Order
import com.example.govind.domain.repository.GovindRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class OrdersUiState(
    val isLoading: Boolean = true,
    val orders: List<Order> = emptyList(),
    val error: String? = null,
    val deliveryLocations: Map<String, com.example.govind.data.model.DeliveryLocation> = emptyMap()
)

@HiltViewModel
class OrdersViewModel @Inject constructor(
    private val repository: GovindRepository,
    private val trackingRepository: com.example.govind.domain.repository.TrackingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(OrdersUiState())
    val uiState: StateFlow<OrdersUiState> = _uiState.asStateFlow()

    private val trackedOrderIds = mutableSetOf<String>()

    init {
        loadOrders()
    }

    private fun loadOrders() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            try {
                repository.getOrders().collect { orders ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        orders = orders.sortedByDescending { it.createdAt }
                    )
                    
                    orders.filter { it.orderStatus == "OUT_FOR_DELIVERY" }.forEach { order ->
                        if (!trackedOrderIds.contains(order.id)) {
                            trackedOrderIds.add(order.id)
                            viewModelScope.launch {
                                trackingRepository.listenToOrderTracking(order.id).collect { loc ->
                                    if (loc != null) {
                                        val map = _uiState.value.deliveryLocations.toMutableMap()
                                        map[order.id] = loc
                                        _uiState.value = _uiState.value.copy(deliveryLocations = map)
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Failed to load orders"
                )
            }
        }
    }
}
