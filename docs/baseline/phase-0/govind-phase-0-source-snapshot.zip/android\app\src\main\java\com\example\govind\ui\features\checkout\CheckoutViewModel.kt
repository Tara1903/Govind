package com.example.govind.ui.features.checkout

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.govind.data.model.Address
import com.example.govind.data.model.Cart
import com.example.govind.domain.repository.GovindRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import javax.inject.Inject

data class CheckoutUiState(
    val isLoading: Boolean = true,
    val cart: Cart? = null,
    val totalAmount: Double = 0.0,
    val addresses: List<Address> = emptyList(),
    val selectedAddressId: String? = null,
    val selectedPaymentMethod: String = "COD",
    val orderPlaced: Boolean = false,
    val checkoutUrl: String? = null,
    val error: String? = null,
    val needsPhone: Boolean = false,
    val phoneSaved: Boolean = false
)

@HiltViewModel
class CheckoutViewModel @Inject constructor(
    private val repository: GovindRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CheckoutUiState())
    val uiState: StateFlow<CheckoutUiState> = _uiState.asStateFlow()

    init {
        loadCheckoutData()
    }

    private fun loadCheckoutData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            try {
                repository.getGlobalCart().collect { cart ->
                    var total = 0.0
                    cart?.items?.forEach { item ->
                        val result = com.example.govind.domain.pricing.PricingEngine.calculateProductPrice(
                            basePrice = item.product.sellingPrice,
                            quantity = item.quantity,
                            wholesalePricing = item.product.getWholesalePricing(),
                            experience = "FRESH" // TODO pass experience
                        )
                        total += result.subtotal
                    }
                    _uiState.value = _uiState.value.copy(
                        cart = cart,
                        totalAmount = total
                    )
                }
            } catch (e: Exception) {
                // Ignore for now
            }
        }
        
        viewModelScope.launch {
            try {
                repository.getAddresses().collect { addresses ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        addresses = addresses,
                        selectedAddressId = addresses.firstOrNull { it.isDefault }?.id ?: addresses.firstOrNull()?.id
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message
                )
            }
        }
        
        viewModelScope.launch {
            try {
                val profileResult = repository.getUserProfile()
                if (profileResult.isSuccess) {
                    val profile = profileResult.getOrNull()
                    if (profile?.phone.isNullOrBlank()) {
                        _uiState.value = _uiState.value.copy(needsPhone = true)
                    }
                }
            } catch (e: Exception) {
                // Ignore profile fetch failure
            }
        }
    }
    
    fun selectAddress(addressId: String) {
        _uiState.value = _uiState.value.copy(selectedAddressId = addressId)
    }
    
    fun selectPaymentMethod(method: String) {
        _uiState.value = _uiState.value.copy(selectedPaymentMethod = method)
    }
    
    fun savePhoneNumber(phone: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val result = repository.updateUserPhone(phone)
            if (result.isSuccess) {
                _uiState.value = _uiState.value.copy(needsPhone = false, isLoading = false, phoneSaved = true)
            } else {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = result.exceptionOrNull()?.message ?: "Failed to save phone number"
                )
            }
        }
    }
    
    fun placeOrder() {
        val state = _uiState.value
        val addressId = state.selectedAddressId ?: return
        
        viewModelScope.launch {
            _uiState.value = state.copy(isLoading = true)
            val result = repository.placeGlobalOrder(addressId, state.selectedPaymentMethod)
            if (result.isSuccess) {
                _uiState.value = state.copy(isLoading = false, orderPlaced = true, checkoutUrl = result.getOrNull()?.checkoutUrl)
            } else {
                _uiState.value = state.copy(
                    isLoading = false,
                    error = result.exceptionOrNull()?.message ?: "Failed to place order"
                )
            }
        }
    }
}









