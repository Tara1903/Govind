"use client";

import { useState, useEffect, useTransition } from "react";
import { updateOrderStatus } from "./actions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { createClient } from "../../../../utils/supabase/client";

const STATUS_FLOW = [
  "PENDING",
  "CONFIRMED",
  "PREPARING",
  "READY_FOR_DELIVERY",
  "OUT_FOR_DELIVERY",
  "DELIVERED"
];

export default function OrderDetailsClient({ order, items }: { order: any, items: any[] }) {
  const [isPending, startTransition] = useTransition();
  const supabase = createClient();
  const [locationInfo, setLocationInfo] = useState<{ eta?: string, distance?: string, updated_at?: string } | null>(null);

  const currentStatusIndex = STATUS_FLOW.indexOf(order.order_status);
  const nextStatus = currentStatusIndex !== -1 && currentStatusIndex < STATUS_FLOW.length - 1 
    ? STATUS_FLOW[currentStatusIndex + 1] 
    : null;

  const handleAdvanceStatus = () => {
    if (nextStatus) {
      startTransition(() => {
        updateOrderStatus(order.id, nextStatus);
      });
    }
  };

  useEffect(() => {
    if (order.order_status === "OUT_FOR_DELIVERY" && order.delivery_partner_id) {
      // Fetch initial location
      const fetchLocation = async () => {
        const { data } = await supabase
          .from("delivery_locations")
          .select("eta, distance, created_at")
          .eq("delivery_partner_id", order.delivery_partner_id)
          .order("created_at", { ascending: false })
          .limit(1)
          .single();
        if (data) {
          setLocationInfo({ eta: data.eta, distance: data.distance, updated_at: data.created_at });
        }
      };
      fetchLocation();

      // Subscribe to updates
      const channel = supabase
        .channel(`locations_${order.delivery_partner_id}`)
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "delivery_locations",
            filter: `delivery_partner_id=eq.${order.delivery_partner_id}`,
          },
          (payload) => {
            const newLoc = payload.new as any;
            setLocationInfo({ eta: newLoc.eta, distance: newLoc.distance, updated_at: newLoc.created_at });
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [order.order_status, order.delivery_partner_id, supabase]);

  const itemsByCategory = items.reduce((acc, item) => {
    const cat = item.products?.category || "Other";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(item);
    return acc;
  }, {} as Record<string, any[]>);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Order #{order.id.split("-")[0]}</h2>
        <div className="flex gap-2">
          {nextStatus && (
            <Button 
              onClick={handleAdvanceStatus} 
              disabled={isPending}
            >
              {isPending ? "Updating..." : `Advance to ${nextStatus.replace(/_/g, " ")}`}
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Customer Details</CardTitle></CardHeader>
          <CardContent>
            <p><strong>Name:</strong> {order.profiles?.name || "Guest"}</p>
            <p><strong>Phone:</strong> {order.profiles?.phone || "N/A"}</p>
            <p><strong>Address:</strong> {order.delivery_address || order.profiles?.address || "N/A"}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader><CardTitle>Status</CardTitle></CardHeader>
          <CardContent>
            <p className="mb-2"><strong>Current:</strong> {order.order_status.replace(/_/g, " ")}</p>
            
            {order.order_status === "OUT_FOR_DELIVERY" && order.delivery_partner_id && (
              <div className="mt-4 p-4 border rounded bg-blue-50 text-blue-900 flex flex-col gap-1">
                <p className="font-semibold text-lg">Live Tracking</p>
                {locationInfo ? (
                  <>
                    <p><strong>ETA:</strong> {locationInfo.eta || "Calculating..."}</p>
                    <p><strong>Distance:</strong> {locationInfo.distance || "..."}</p>
                    <p className="text-xs text-blue-700">Last updated: {new Date(locationInfo.updated_at!).toLocaleTimeString()}</p>
                  </>
                ) : (
                  <p>Awaiting location update...</p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Order Items</CardTitle></CardHeader>
        <CardContent>
          {Object.keys(itemsByCategory).map((cat) => (
            <div key={cat} className="mb-6">
              <h3 className="text-xl font-semibold mb-2">{cat}</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Historical Price</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {itemsByCategory[cat].map((item: any) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.products?.name || "Unknown Product"}</TableCell>
                      <TableCell>{item.quantity} {item.products?.unit || ""}</TableCell>
                      <TableCell>₹{item.price_at_time}</TableCell>
                      <TableCell className="text-right">₹{item.quantity * item.price_at_time}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
